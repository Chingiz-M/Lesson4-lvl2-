﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj3
{/*Задание: 3. *Дан фрагмент программы:
            Dictionary<string, int> dict = new Dictionary<string, int>()
                {
                {"four",4 },
                {"two",2 },
                { "one",1 },
                {"three",3 },
                };
                    var d = dict.OrderBy(delegate(KeyValuePair<string,int> pair) { return pair.Value; });
                    foreach (var pair in d)
                {
                    Console.WriteLine("{0} - {1}", pair.Key, pair.Value);
                }
                    а) Свернуть обращение к OrderBy с использованием лямбда-выражения $.
                    б) *Развернуть обращение к OrderBy с использованием делегата Predicate<T>.
    
  *Фамилия: Орлов
  */
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, int> dict = new Dictionary<string, int>()
            {
                {"four",4 },
                {"two",2 },
                { "one",1 },
                {"three",3 },
            };
            dict.OrderBy(p => p.Value).ToList().ForEach(p => Console.WriteLine("{0}\t-  {1}", p.Key, p.Value)); // 3
            Console.ReadKey(true);
        }
    }
}
