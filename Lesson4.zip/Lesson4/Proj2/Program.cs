﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj2
{/*Задание: 2.  Дана коллекция List<T>, требуется подсчитать, сколько раз каждый элемент встречается в данной коллекции:
                а) для целых чисел;
                б) *для обобщенной коллекции;
                в) *используя Linq.

  *Фамилия: Орлов
  */
    public static class MyClass
    {
        public static void GetCountItemsInList(this List<int> self)
        {
            Dictionary<int, int> pairs = new Dictionary<int, int>();
            self.ForEach(s => { if (!pairs.ContainsKey(s)) pairs.Add(s, 1); else pairs[s]++; });
            pairs.ToList().ForEach(p => Console.WriteLine($"Значение: {p.Key}\t Количество: {p.Value}")); 
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>() { 1, 2, 3, 4, 1, 4, 5, 5, 6, 7, 7, 7, 8, 9 };
            list.GetCountItemsInList(); //2
            Console.ReadKey(true);
        }
    }
}
